import "./App.css";
import "./assets/icon/font-awesome/css/font-awesome.min.css";

import About from "./components/About/About";
import Filter from "./components/Dashboard/Filter/Filter";
import Table from "./components/Dashboard/Table/Table";
import Header from "./components/Header/Header";
import Login from "./components/Login/Login";
import PriceCard from "./components/PriceCard/PriceCard";
import Register from "./components/Register/Register";

function App() {
  return (
    <div>
      <Header />
      <Register />
    </div>
  );
}

export default App;
