import "./PriceCard.css";

const PriceCard = () => {
  return (
    <div>
      <h1>Price card.js</h1>
    </div>
  );
};

export default PriceCard;
