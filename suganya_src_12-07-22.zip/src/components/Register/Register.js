import "./Register.css";

const Register = () => {
  return (
    <div>
      <div className="container">
        <div className="row mt-5">
          <div className="col-3"></div>
          <div className="col-md-6">
            {/* <!-- signup form --> */}
            <form className="p-4 signup-form rounded">
              <h3 className="text-center mb-3">Signup Now!</h3>
              <div className=" form-floating mb-3">
                <input
                  type="text"
                  className="form-control"
                  id="firstName"
                  placeholder="First Name"
                  required
                  pattern="^[A-Za-z]+{1,20}$"
                />
                <label htmlFor="firstName">First Name</label>
              </div>
              <div className="form-floating mb-3">
                <input
                  type="text"
                  className="form-control"
                  id="lastName"
                  placeholder="Last Name"
                  required
                  pattern="^[A-Za-z]+{1,20}$"
                />
                <label htmlFor="lastName">Last Name</label>
              </div>
              <div className=" form-floating mb-3">
                <input
                  type="email"
                  className="form-control"
                  id="email"
                  aria-describedby="emailHelp"
                  placeholder="Email Address"
                  required
                />
                <label htmlFor="email">Email address</label>

                <div id="emailHelp" className="form-text">
                  Your email will be a username
                </div>
              </div>
              <div className="form-floating mb-3">
                <input
                  type="password"
                  className="form-control"
                  id="password"
                  placeholder="Password"
                  required
                  pattern="((?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*()_+=-]).{6,15})"
                />
                <label htmlFor="password">Password</label>
              </div>
              <button type="submit" className="btn">
                Submit
              </button>
            </form>
          </div>
          <div className="col-3"></div>
        </div>
      </div>
    </div>
  );
};

export default Register;
