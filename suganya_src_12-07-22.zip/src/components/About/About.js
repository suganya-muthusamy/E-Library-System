import "./About.css";

const About = () => {
  return (
    <div>
      <h1>Aboutus</h1>
    </div>
  );
};

export default About;
