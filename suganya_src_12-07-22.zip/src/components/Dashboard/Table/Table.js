import "./Table.css";

const Table = () => {
  return (
    <div>
      <h1>Table.js</h1>
    </div>
  );
};

export default Table;
