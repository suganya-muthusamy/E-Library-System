import "./Filter.css";

const Filter = () => {
  return (
    <div>
      <h1>Filter.js</h1>
    </div>
  );
};

export default Filter;
